# LLM & Agent Context (Template)

This directory contains structured prompts, documentation, and planning notes
for AI agents and developers working in this repository.

## Structure

```text
.llm/
├─ 02dev/
│  ├─ prompt.md          # Dev environment guidance (markdown)
│  └─ prompt.txt         # Dev environment guidance (plain text)
├─ 01stg/
│  ├─ prompt.md          # Staging environment guidance
│  └─ prompt.txt
├─ 00prd/
│  ├─ prompt.md          # Production environment guidance
│  └─ prompt.txt
├─ docs/
│  ├─ DEVELOPMENT.md     # Local dev setup and testing
│  ├─ DEPLOYMENTS.md     # Promotion workflow and procedures
│  ├─ TROUBLESHOOTING.md # Common issues and solutions
│  ├─ AGENTS.md          # Agent-specific guidance (optional)
│  └─ mcp.json           # MCP server configuration (no secrets)
└─ plans/
   ├─ UPDATES.md         # WIP improvements and experiments
   ├─ INCIDENTS.md       # Production incidents and postmortems
   └─ RESEARCH.md        # Investigation notes and design docs
```

## Quick Navigation

| File | Purpose |
| ---- | ------- |
| `02dev/prompt.txt` | Rapid iteration, local testing, early validation. |
| `01stg/prompt.txt` | Pre-production validation, mirrors production setup. |
| `00prd/prompt.txt` | Production environment guidance—stability, security. |
| `docs/DEVELOPMENT.md` | Local dev setup (wrangler, .dev.vars, testing). |
| `docs/DEPLOYMENTS.md` | Dev→stg→prd workflow with checklists. |
| `docs/TROUBLESHOOTING.md` | Common issues and solutions. |

## For Developers

1. Start with `docs/DEVELOPMENT.md`.
2. Follow `docs/DEPLOYMENTS.md` when promoting.
3. Use `docs/TROUBLESHOOTING.md` for common errors.
4. Update prompts and plans as your workflows evolve.

## For AI Agents & Automation

Environment-specific prompts tailor guidance based on context:

- **Dev work** → `02dev/prompt.txt`
- **Staging validation** → `01stg/prompt.txt`
- **Production** → `00prd/prompt.txt`

All prompts inherit repository rules in `AGENTS.md` and
`.github/copilot-instructions.md`.

## Security & Confidentiality

- Keep `.llm/` files git-safe: **no secrets, API keys, or tokens**.
- Use `.dev.vars` for local secrets and `wrangler secret put` for deployed
  secrets.
- Sanitize `.llm/plans/` entries before committing.

## References

- `README.md` — Monorepo overview and conventions.
- `CHANGELOG.md` — Monorepo history.
- `.github/copilot-instructions.md` — Agent rules.
- `AGENTS.md` — Repository guidelines.
- `com-*/README.md` — Tenant-specific details.

