# Local Development Guide (Template)

## Getting Started

### Prerequisites

1. Install Cloudflare wrangler CLI:

   ```bash
   npm i -g wrangler
   ```

2. Log in to Cloudflare:

   ```bash
   wrangler login
   ```

3. Navigate to a tenant env folder:

   ```bash
   cd com-yourbrand/02dev
   ```

### Local Development Server

Start a local development environment that mimics edge behavior:

```bash
wrangler dev src/index.ts --test-scheduled --var ENV=dev --local
```

**Flags:**

- `--test-scheduled` — Allows manual triggering of cron handlers.
- `--var ENV=dev` — Set an environment variable (adjust as needed).
- `--local` — Run KV, D1, Durable Objects locally without hitting Cloudflare.

Access the dev server at `http://localhost:8787` (or the port wrangler assigns).

### Environment Variables & Secrets

**Local development (.dev.vars):**

1. Create a `.dev.vars` file in the env folder (e.g., `com-yourbrand/02dev/.dev.vars`).
2. Add key-value pairs (git-ignored, safe for local testing):

   ```bash
   API_KEY=dev-test-key-xyz
   DATABASE_URL=http://localhost:8787/db
   ```

3. Wrangler loads these automatically when running `wrangler dev`.

**Cloudflare-managed secrets:**

- For dev/staging/production, use:

  ```bash
  wrangler secret put SECRET_NAME --env dev
  # or stg / prd
  ```

- Never commit secrets to git.

### Testing

#### Unit Tests

- Keep tests Node-based for speed.
- Mock Cloudflare services (KV, D1, R2) using small fixtures.
- Run tests locally before deploying:

  ```bash
  npm test
  # or your configured test runner
  ```

#### Edge-Like Testing

- Use `wrangler dev --local` to test Durable Objects, KV, and D1 in a more
  realistic edge context.
- Manually trigger cron handlers with `--test-scheduled`.

### Debugging

#### Console Output

- Use `console.log()` during local development for quick feedback.
- Keep logging minimal in production; rely on `wrangler tail` instead.

#### Live Logs (Deployed Code)

```bash
wrangler tail --env dev
```

- Streams real-time logs from a deployed environment.
- Useful for debugging issues that only appear in deployed code.

#### Accessing Dev KV & D1 Data

- When running `wrangler dev --local`, data is stored in `.wrangler/state/`.
- To reset, delete the state folder and restart `wrangler dev`.

### Deploying from Dev

Once tested locally, deploy to the dev environment:

```bash
wrangler deploy --env dev
```

Then validate:

```bash
wrangler tail --env dev
# Check logs for errors
```

### Plan Limits to Keep in Mind

- Cloudflare plan limits change over time. Check current limits before load
  testing or shipping performance-sensitive features.
- Avoid unbounded loops, large payloads, or expensive DB scans.

### Common Local Dev Issues

#### Q: `wrangler dev` doesn't start

- A: Ensure `wrangler.jsonc` exists in the env folder and references a valid
  `main` field.

#### Q: Changes aren't reflected locally

- A: Restart `wrangler dev` or save the file again to trigger hot reload.

#### Q: Secrets aren't loading in `.dev.vars`

- A: Ensure the file is in the env folder (e.g., `com-yourbrand/02dev/.dev.vars`),
  and restart `wrangler dev`.

### Next Steps

- Read `DEPLOYMENTS.md` for the dev→stg→prd promotion workflow.
- Check `TROUBLESHOOTING.md` for common issues and fixes.
- Review `.github/copilot-instructions.md` for broader guidance.

