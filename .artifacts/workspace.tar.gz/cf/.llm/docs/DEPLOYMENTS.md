# Deployment & Promotion Workflow (Template)

## Overview

The monorepo follows a three-tier promotion flow:

```text
02dev → 01stg → 00prd
 ↓       ↓       ↓
Local   Preview Production
sandbox          (Live users)
```

Each tier validates and gates the next. **Never skip a tier or deploy directly
into production.**

## Workflow Steps

### 1. Development (02dev)

**Goal:** Rapid iteration, local testing, early validation.

1. Make changes in the source tree.
2. Run locally:

   ```bash
   cd com-yourbrand/02dev
   wrangler dev src/index.ts --test-scheduled --var ENV=dev --local
   ```

3. Run tests:

   ```bash
   npm test
   ```

4. Deploy to dev:

   ```bash
   wrangler deploy --env dev
   ```

5. Verify in dev:

   ```bash
   wrangler tail --env dev
   ```

6. Update `CHANGELOG.md` in the dev folder with your changes.
7. Commit your changes and open a PR.

### 2. Code Review & Merge

1. Code review in the PR; ensure tests pass and CHANGELOG is updated.
2. Merge to `main` once approved.
3. Validate the merge:

   ```bash
   wrangler deploy --env dev
   wrangler tail --env dev
   ```

### 3. Staging (01stg)

**Goal:** Pre-production validation—mirror production setup, full integration
checks.

1. Deploy to staging:

   ```bash
   cd com-yourbrand/01stg
   wrangler deploy --env stg
   ```

2. Set or rotate secrets in staging:

   ```bash
   wrangler secret put SECRET_NAME --env stg
   ```

3. Run integration tests against staging APIs.
4. Manual smoke testing on staging URLs.
5. Monitor logs:

   ```bash
   wrangler tail --env stg
   ```

6. Validate performance metrics (CPU time, latency, error rate).
7. Update `CHANGELOG.md` in the stg folder (if staging-specific changes were
   needed).

### 4. Production (00prd)

**Goal:** Stable, customer-facing environment.

#### Pre-Deployment Checklist

- [ ] Code validated in dev.
- [ ] Full validation passed in staging.
- [ ] CHANGELOG.md updated with version and user-visible changes.
- [ ] Data migrations tested (if applicable).
- [ ] Secrets set in production.
- [ ] Rollback plan documented.

#### Deployment

1. Deploy to production:

   ```bash
   cd com-yourbrand/00prd
   wrangler deploy --env prd
   ```

2. Monitor:

   ```bash
   wrangler tail --env prd
   ```

3. Verify customer-facing URLs and key endpoints.
4. Check analytics and error logs for anomalies.

#### If Issues Occur

- Revert to the previous deploy.
- Investigate root cause.
- Fix on dev, validate through stg, then re-deploy prd.
- Document incident in `.llm/plans/INCIDENTS.md`.

## Environment Variables & Secrets

### Per-Environment Configuration

Each tenant/env folder has its own `wrangler.jsonc`:

```text
com-yourbrand/02dev/wrangler.jsonc
com-yourbrand/01stg/wrangler.jsonc
com-yourbrand/00prd/wrangler.jsonc
```

Use `wrangler.jsonc` to:

- Define environment-specific routes and domains.
- Configure KV namespace bindings (separate for dev/stg/prd).
- Configure D1 database bindings (separate for dev/stg/prd).
- Set environment variables via `vars` or `define`.

### Secrets Management

Secrets are **not** stored in `wrangler.jsonc`. Instead:

```bash
wrangler secret put MY_SECRET --env dev
wrangler secret put MY_SECRET --env stg
wrangler secret put MY_SECRET --env prd
```

Access them in code via `env.MY_SECRET`.

