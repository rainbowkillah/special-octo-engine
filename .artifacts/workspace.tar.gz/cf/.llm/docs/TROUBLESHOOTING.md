# Troubleshooting Guide (Template)

Common issues and solutions for local development, staging, and production.

---

## Local Development

### Issue: `wrangler dev` fails to start

**Symptom:** Error like `Error: No entry point found` or `wrangler.jsonc not found`.

**Solution:**

1. Ensure you're in the correct env folder:

   ```bash
   cd com-yourbrand/02dev
   ```

2. Check that `wrangler.jsonc` exists and has a valid `main` entry.

---

### Issue: Changes aren't reflected locally

**Solution:**

1. Save the file again (hot reload should trigger).
2. Restart `wrangler dev`.
3. Clear browser cache if testing in a browser.

---

### Issue: Secrets/environment variables not loading

**Solution:**

1. Ensure `.dev.vars` exists in the env folder.
2. Restart `wrangler dev`.
3. For deployed secrets, confirm with `wrangler secret list --env dev`.

---

## Deployment & Staging

### Issue: `wrangler deploy` fails with authentication error

**Solution:**

1. Run `wrangler login`.
2. Confirm with `wrangler whoami`.
3. Verify your Cloudflare account has access to the target zone/account.

---

### Issue: Deployment succeeds but requests fail

**Solution:**

1. Check logs:

   ```bash
   wrangler tail --env dev
   ```

2. Confirm routes/domains in `wrangler.jsonc` match the expected URL.
3. Check for missing bindings (KV/D1/R2) in `wrangler.jsonc`.

---

## Production

### Issue: Elevated error rates after deploy

**Solution:**

1. Keep `wrangler tail --env prd` running to capture errors.
2. Roll back to the previous deploy if errors persist.
3. Document the incident in `.llm/plans/INCIDENTS.md`.

