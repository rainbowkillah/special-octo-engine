# Updates Log (Template)

Use this file for WIP improvements, experiments, and cleanup tasks.

Rules:

- Keep entries brief and dated.
- Remove secrets/PII before committing.
- Promote finalized guidance into `.llm/` prompts/docs.

## 2026-01-03

- Initialize template structure and documentation.
