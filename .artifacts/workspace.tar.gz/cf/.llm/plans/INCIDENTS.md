# Incidents Log (Template)

Use this file for production incidents and postmortems.

Rules:

- No secrets/PII.
- Include date, impact, root cause, and fix.
- Add follow-up actions and owners.

## Template Entry

- Date:
- Impact:
- Detection:
- Root cause:
- Mitigation:
- Follow-ups:
