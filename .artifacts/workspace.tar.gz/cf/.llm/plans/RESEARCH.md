# Research Notes (Template)

Use this file for investigation notes, design sketches, and decisions that are
not ready for permanent docs.

Rules:

- Keep sections scoped and dated.
- Summarize conclusions at the end of each section.
- Remove secrets/PII before committing.

## 2026-01-03

- Placeholder research entry.
